PDF to Kindle Touch (Pdf2KT)

deathvoyage.wordpress.com
https://github.com/skpdvdd/Pdf2KT

See License.txt
